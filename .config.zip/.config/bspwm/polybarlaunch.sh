#!/usr/bin/env sh
pkill polybar && sleep 1
polybar -c /home/skilax/.config/bspwm/polybar/config.ini &
